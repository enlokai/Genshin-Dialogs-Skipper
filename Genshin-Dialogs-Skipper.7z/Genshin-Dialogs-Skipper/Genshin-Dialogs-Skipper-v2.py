from ahk import AHK
import keyboard
import multiprocessing
import os
import psutil
import time


def startSkipping(stopSignal):
    keyboard.wait('Insert')
    while not stopSignal.is_set():
        win.click()

def startSkippingMouseStatic(stopSignal):
    keyboard.wait('Insert')
    while not stopSignal.is_set():
        ahk.click(1547, 799, coord_mode='Screen')
        ahk.click(1545, 750, coord_mode='Screen')
        win.send('f')


def stopSkipping(stopSignal):
    keyboard.wait('Delete')
    stopSignal.set()


def killSkipper(stopSignal):
    keyboard.wait('End')
    stopSignal.set()
    os.system("taskkill -f -im AutoHotkey64.exe")
    os.system("taskkill -f -im python.exe")


def getGenshinPID():
    for process in psutil.process_iter(['pid', 'name']):
        if process.info['name'] == 'GenshinImpact.exe':
            return process.info['pid']
        else:
            os.system("cls")
            print("\n\t[ERROR]: Are you sure Genshin Impact up and running?\n")
            time.sleep(2)
            killSkipper()
    return None


pid = getGenshinPID()
ahk = AHK(executable_path='C:/Program Files/AutoHotkey/v2/AutoHotkey.exe')
win = ahk.win_get(title='ahk_pid {}'.format(pid))


if __name__ == "__main__":
    stopSignal = multiprocessing.Event()
    kill_process = multiprocessing.Process(target=killSkipper, args=(stopSignal,))
    kill_process.start()

    while True:
        os.system("cls")
        isMouseStatic = input("Which version of the script do you want to use?:\n\n"
                              "\tVersion №1 | You move the mouse cursor.\n"
                              "\tVersion №2 | The mouse cursor is fixed in the dialog area.\n\n"
                              "Enter your choice (1 or 2) > ")
        
        if int(isMouseStatic) == 1:
            os.system("cls")
            print("\n\t~ The script is up and running! ~"
                  "\n\tYou have chosen FREE mouse control."
                  "\n\tPress 'Insert' button to START"
                  "\n\tPress 'Delete' button to PAUSE"
                  "\n\tPress 'End' button to STOP")

            while True:
                    stopSignal = multiprocessing.Event()
                    loop_process = multiprocessing.Process(target=startSkipping, args=(stopSignal,))
                    keyboard_process = multiprocessing.Process(target=stopSkipping, args=(stopSignal,))
                    
                    loop_process.start()
                    keyboard_process.start()

                    loop_process.join()
                    keyboard_process.join()

        elif int(isMouseStatic) == 2:
            os.system("cls")
            print("\n\t~ The script is up and running! ~"
                  "\n\tYou have selected STATIC mouse placement."
                  "\n\tPress 'Insert' button to START"
                  "\n\tPress 'Delete' button to PAUSE"
                  "\n\tPress 'End' button to STOP")

            while True:
                    stopSignal = multiprocessing.Event()
                    loop_process = multiprocessing.Process(target=startSkippingMouseStatic, args=(stopSignal,))
                    keyboard_process = multiprocessing.Process(target=stopSkipping, args=(stopSignal,))
                    
                    loop_process.start()
                    keyboard_process.start()

                    loop_process.join()
                    keyboard_process.join()
        else:
            print("Wrong! You are only allowed to enter '1' or '2' as an answer.")
            time.sleep(2)
            continue



    